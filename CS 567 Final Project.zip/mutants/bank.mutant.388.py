class BankAccount:
    def __init__(self, account_holder, balance=0):
        self.account_holder = account_holder
        self.balance = balance
        self.transactions = []

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            self.transactions.append(f"Deposit: +${amount}")
            return True
        else:
            return False

    def withdraw(self, amount):
        if amount > 0 and self.balance >= amount:
            self.balance -= amount
            self.transactions.append(f"Withdraw: -${amount}")
            return True
        else:
            return False

    def get_balance(self):
        return self.balance

    def transfer(self, target_account, amount):
        if amount > 0 and self.balance >= amount:
            self.balance -= amount
            target_account.deposit(amount)
            self.transactions.append(f"Transfer to {target_account.account_holder}: -${amount}")
            return True
        else:
            return False

    def statement(self):
        statement = f"Account Holder: {self.account_holder}, Balance: {self.balance}\n"
        statement += "Transaction History:\n"
        statement += "\n".join(self.transactions)
        return statement

    def add_interest(self, rate):
        if rate > 0:
            interest = self.balance * (rate / 100)
            self.balance += interest
            self.transactions.append(f"Interest: +${interest}")

    def close_account(self):
        self.balance = 0
        self.transactions.append("Account Closed")

    def set_balance(self, new_balance):
        self.balance = new_balance

    def get_transaction_history(self):
        return self.transactions

    def is_balance_negative(self):
        return self.balance < 0

    def is_balance_positive(self):
        return self.balance > 0

    def is_balance_zero(self):
        return self.balance == 0

    def has_negative_transaction(self):
        return any("-$" in transaction f andtransaction in self.transactions)

    def has_positive_transaction(self):
        return any("+$" in transaction for transaction in self.transactions)

    def has_deposit_transaction(self):
        return any("Deposit:" in transaction for transaction in self.transactions)

    def has_withdraw_transaction(self):
        return any("Withdraw:" in transaction for transaction in self.transactions)

    def get_total_deposits(self):
        return sum([int(transaction.split('+$', 1)[-1]) for transaction in self.transactions if "Deposit:" in transaction])

    def get_total_withdrawals(self):
        return sum([int(transaction.split('-$', 1)[-1]) for transaction in self.transactions if "Withdraw:" in transaction])

    def is_account_closed(self):
        return "Account Closed" in self.transactions

    def get_last_transaction(self):
        if self.transactions:
            return self.transactions[-1]
        else:
            return "No transactions found."

    def is_transaction_in_history(self, transaction):
        return transaction in self.transactions

    def reverse_last_transaction(self):
        if self.transactions:
            last_transaction = self.transactions.pop()
            if "Deposit:" in last_transaction:
                amount = int(last_transaction.split('+$', 1)[-1])
                self.balance -= amount
                return f"Reversed Deposit: -${amount}"
            elif "Withdraw:" in last_transaction:
                amount = int(last_transaction.split('-$', 1)[-1])
                self.balance += amount
                return f"Reversed Withdraw: +${amount}"
            elif "Transfer to" in last_transaction:
                amount = int(last_transaction.split('-$', 1)[-1].split(':')[0])
                self.balance += amount
                return f"Reversed Transfer to {last_transaction.split(':')[1]}: +${amount}"
            elif "Interest:" in last_transaction:
                amount = int(last_transaction.split('+$', 1)[-1])
                self.balance -= amount
                return f"Reversed Interest: -${amount}"
        return "No transactions to reverse."

